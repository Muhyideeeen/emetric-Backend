from .detail import Task
from .submission import TaskSubmission
