from django.apps import AppConfig


class EmployeeProfileConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'employee_profile'
