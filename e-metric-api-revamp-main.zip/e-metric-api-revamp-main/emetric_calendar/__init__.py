
default_app_config =    "emetric_calendar.apps.EmetricCalendarConfig"