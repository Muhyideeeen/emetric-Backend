from django.contrib import admin
from . import models
# Register your models here.



admin.site.register(models.EmployeeFile)
admin.site.register(models.EmployeeFileName)