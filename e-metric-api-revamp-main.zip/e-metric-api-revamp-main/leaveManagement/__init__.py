
"i did this for https://github.com/django-tenants/django-tenants/issues/577 check  marcsabat commented on Sep 8, 2021 .that the  comment"


default_app_config  = "leaveManagement.apps.LeavemanagementConfig"