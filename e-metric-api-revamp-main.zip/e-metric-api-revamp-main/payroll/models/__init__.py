from . import monthly_salary_structure
from . import generated_employee_montly_structure